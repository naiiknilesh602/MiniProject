﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.ServiceModel;
using System.Text;

using System.Threading.Tasks;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using System.Text.Json;
using Microsoft.Crm.Sdk.Messages;
using System.IdentityModel.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System.Reflection;
using System.Diagnostics;
using System.Linq.Expressions;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;
using System.Diagnostics.Contracts;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace UpdateAddressDetails
{
    public class UpdateAddressDetails : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            ITracingService tracer = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity target = context.InputParameters["Target"] as Entity;
            tracer.Trace("CustomerService Address Details Update Started");
            tracer.Trace("CustomerService Address Details Update Started" + context.InputParameters["Target"]);
            tracer.Trace("CustomerService Address Details Update Plugin Depth :" + context.InputParameters.Contains("Target"));
            tracer.Trace("CustomerService Address Details Update Plugin Depth :" + context.Depth);
            tracer.Trace("Message :" + context.MessageName.ToString());
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                Entity CaseIncident = new Entity("incident");
                try
                {
                    //// Post-Event - Post Operation Stage
                    if (context.Stage == 40)
                    {
                        if (context.Depth > 1)
                        {
                            return;
                        }
                        Entity postMessageImage = new Entity();
                        if (context.MessageName == "Update")
                        {
                            if (context.PostEntityImages.Contains("PostImage") && context.PostEntityImages["PostImage"] is Entity)
                            {
                                postMessageImage = (Entity)context.PostEntityImages["PostImage"];

                                string caseApprovalOptionSet = "ss_customerapproval";
                                if (postMessageImage.Contains(caseApprovalOptionSet))
                                {
                                    // Retrieve the Customer Approval OptionSet value
                                    int caseApprovalOptionSetValueInt = ((OptionSetValue)postMessageImage[caseApprovalOptionSet]).Value;
                                    // Get the integer value of the Customer Approval OptionSet
                                    if (caseApprovalOptionSetValueInt == 0) // Case is Approved
                                    {
                                        if (postMessageImage.Contains("new_requesttypeid"))
                                        { // Retrieve the Sub Case Type 
                                            Guid preSubCaseType = ((EntityReference)postMessageImage.Attributes["new_requesttypeid"]).Id;
                                            string preSubCaseTypeName = ((EntityReference)(postMessageImage.Attributes["new_requesttypeid"])).Name.ToString();

                                            tracer.Trace(" preSubCaseType :" + preSubCaseType);
                                            if (postMessageImage.Contains("ccs_contract"))
                                            {
                                                EntityReference ContractEntityRef = (EntityReference)postMessageImage.Attributes["ccs_contract"];
                                                if (postMessageImage.Contains("customerid"))
                                                {
                                                    Guid customerID = ((EntityReference)postMessageImage.Attributes["customerid"]).Id;
                                                    var contractList = GetContractDetails(service, tracer, ContractEntityRef.Id, entity.Id);
                                                    bool isAutoFin = false;
                                                    bool isCaseClose = true;
                                                    //foreach (ContractDetail contractDetail in contractList.ContractDetails)
                                                    for (int i = 0; contractList.ContractDetails.Count > i; i++)
                                                    {
                                                        // tracer.Trace("REFERENCE_NUMBER:" + contractDetail.REFERENCE_NUMBER);
                                                        if (isCaseClose)
                                                        {

                                                            if (contractList.ContractDetails[i].REFERENCE_NUMBER.StartsWith("00"))
                                                            {

                                                                // Start the logic for FineOne
                                                                string contract = contractList.ContractDetails[i].REFERENCE_NUMBER;
                                                                var token = generateToken(service, tracer); // Get Token from API
                                                                if (token != null)
                                                                {
                                                                    var customerNumner = getCustomerNumber(token, contract, service, tracer);// Get Customer Number from API
                                                                    if (customerNumner != null)
                                                                    {
                                                                        if (preSubCaseTypeName == "Address Change/Guarantor Change")
                                                                        {
                                                                            var recordId = getRecordID(token, customerNumner, contract, service, tracer);// Get RecordID from API
                                                                            if (recordId != 0)
                                                                            {
                                                                                isCaseClose = updateAddressDetails(recordId.ToString(), token, customerNumner, contract, service, tracer, entity.Id, postMessageImage);
                                                                            }
                                                                        }
                                                                        else if (preSubCaseTypeName == "Identification Detail - DOB")
                                                                        {
                                                                            int personlaDetails = 1;  //Update the DOB
                                                                            isCaseClose = updatePersonalDetails(token, customerNumner, contract, service, tracer, entity.Id, postMessageImage, personlaDetails);
                                                                        }
                                                                        else if (preSubCaseTypeName == "Identification Detail - Gender")
                                                                        {
                                                                            int personlaDetails = 2;  //Update the Gender
                                                                            isCaseClose = updatePersonalDetails(token, customerNumner, contract, service, tracer, entity.Id, postMessageImage, personlaDetails);
                                                                        }
                                                                        else if (preSubCaseTypeName == "Identification Detail - Name")
                                                                        {
                                                                            int personlaDetails = 3;  //Update the Name
                                                                            isCaseClose = updatePersonalDetails(token, customerNumner, contract, service, tracer, entity.Id, postMessageImage, personlaDetails);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            else
                                                            {
                                                                if (!isAutoFin)
                                                                {
                                                                    // Start the logic for AutoFin
                                                                    if (preSubCaseTypeName == "Address Change/Guarantor Change")
                                                                    {
                                                                        isCaseClose = updateAddressForAutoFin(contractList.ContractDetails[i].CLUSTER_ID, service, tracer, postMessageImage, entity.Id);
                                                                        isAutoFin = true;
                                                                    }
                                                                    else if (preSubCaseTypeName == "Identification Detail - DOB" || preSubCaseTypeName == "Identification Detail - Gender" || preSubCaseTypeName == "Identification Detail - Name" || preSubCaseTypeName == "Identification Detail - PAN")
                                                                    {
                                                                        int personlaDetails = 0;
                                                                        if (preSubCaseTypeName == "Identification Detail - DOB")
                                                                        {
                                                                            personlaDetails = 1;  //Update the DOB
                                                                        }
                                                                        else if (preSubCaseTypeName == "Identification Detail - Gender")
                                                                        {
                                                                            personlaDetails = 2;  //Update the Gender
                                                                        }
                                                                        else if (preSubCaseTypeName == "Identification Detail - Name")
                                                                        {
                                                                            personlaDetails = 3;  //Update the Name
                                                                        }
                                                                        else if (preSubCaseTypeName == "Identification Detail - PAN")
                                                                        {
                                                                            personlaDetails = 4;  //Update the PAN
                                                                        }
                                                                        if (personlaDetails != 0)
                                                                        {
                                                                            isCaseClose = updateAutoFinPersonalDetails(contractList.ContractDetails[i].CLUSTER_ID, service, tracer, entity.Id, postMessageImage, personlaDetails);
                                                                            isAutoFin = true;
                                                                        }
                                                                    }

                                                                }
                                                            }
                                                        }

                                                    }
                                                    if (isCaseClose)
                                                    {
                                                        closeCase(entity.Id, service);
                                                    }
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }

                    }
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    tracer.Trace("Exception: {0}", ex.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in the Address Update Plugin.", ex);
                }
                catch (Exception ex)
                {
                    tracer.Trace("Exception: {0}", ex.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in the Address Update Plugin.", ex);
                }
            }
        }
        public class AutoFinUpdateAddressRequestParameter
        {
            public string UserId { get; set; }
            public string Source { get; set; }
        }
        public bool updateAddressForAutoFin(double clusterID, IOrganizationService service, ITracingService tracer, Entity postMessageImage, Guid caseID)
        {
            try
            {
                var url = getConfigValue(service, tracer, "AutoFinAddressUpdateURL");
                string addressTypeCode = null;
                if (postMessageImage.Contains("ss_customeraddresstype"))
                {
                    addressTypeCode = ((OptionSetValue)postMessageImage.Attributes["ss_customeraddresstype"]).Value.ToString();
                }
                string premises = null;
                if (postMessageImage.Contains("ss_premises"))
                {
                    premises = postMessageImage.Attributes["ss_premises"].ToString();
                }
                string postOfficeName = null;
                if (postMessageImage.Contains("ss_postofficename"))
                {
                    postOfficeName = postMessageImage.Attributes["ss_postofficename"].ToString();
                }
                string roadName = null;
                if (postMessageImage.Contains("ss_roadname"))
                {
                    roadName = postMessageImage.Attributes["ss_roadname"].ToString();
                }
                string landMark = null;
                if (postMessageImage.Contains("ss_landmark"))
                {
                    landMark = postMessageImage.Attributes["ss_landmark"].ToString();
                }
                string pinCode = null;
                if (postMessageImage.Contains("ss_customerpincode"))
                {
                    pinCode = postMessageImage.Attributes["ss_customerpincode"].ToString();
                }
                string city = null;
                if (postMessageImage.Contains("ss_customercity"))
                {
                    city = ((EntityReference)postMessageImage.Attributes["ss_customercity"]).Name;
                }
                string state = null;
                if (postMessageImage.Contains("ss_customerstate"))
                {
                    state = ((EntityReference)postMessageImage.Attributes["ss_customerstate"]).Name;

                }
                string taluka = null;
                if (postMessageImage.Contains("ss_customertaluka"))
                {
                    taluka = ((EntityReference)postMessageImage.Attributes["ss_customertaluka"]).Name;
                }
                string district = null;
                if (postMessageImage.Contains("ss_customerdistrict"))
                {
                    district = ((EntityReference)postMessageImage.Attributes["ss_customerdistrict"]).Name;
                }
                string jsonString = getConfigValue(service, tracer, "AutoFinAddressUpdateRequestParameter");
                AutoFinUpdateAddressRequestParameter autoFinUpdateAddressRequestParameter = JsonConvert.DeserializeObject<AutoFinUpdateAddressRequestParameter>(jsonString);
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                var apiKey = getConfigValue(service, tracer, "APIKEYforAddressUpdate");
                request.Headers.Add("apikey", apiKey);
                var loanRequest = new Dictionary<string, string>
                {
                    { "addressTypeCode", addressTypeCode},
                    { "clusterNumber", clusterID.ToString() },
                    { "premises", premises },
                    { "postOfficeName", postOfficeName },
                    { "roadName", roadName },
                    { "landmark", landMark },
                    { "city", city },
                    { "state", state },
                    { "district", district },
                    { "taluka", taluka},
                    { "pinCode", pinCode },
                    { "userId", autoFinUpdateAddressRequestParameter.UserId },
                    { "source", autoFinUpdateAddressRequestParameter.Source }
                };
                var jsonContent = System.Text.Json.JsonSerializer.Serialize(loanRequest);
                // Create StringContent for HTTP request
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                request.Content = content;
                try
                {
                    var response = client.SendAsync(request).Result;
                    response.EnsureSuccessStatusCode();

                    // Ensure success status code
                    // Read the response content as a string
                    var jsonResponse = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    using (JsonDocument document = JsonDocument.Parse(jsonResponse))
                    {
                        if (document.RootElement.TryGetProperty("status", out JsonElement responseCodeElement))
                        {
                            string responseCode = responseCodeElement.GetString();
                            if (responseCode.ToLower() == "success")
                            {
                                Guid ID = createAuditLog("Update Address AutoFin Details", jsonContent, jsonResponse, true, 1, Guid.Empty, caseID, service, tracer);
                                // closeCase(caseID, service);
                            }
                            else
                            {
                                Guid ID = createAuditLog("Update Address AutoFin Details", jsonContent, jsonResponse, false, 1, Guid.Empty, caseID, service, tracer);
                                return false;
                            }
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Guid ID = createAuditLog("Update Address AutoFin Details", jsonContent, ex.Message, false, 1, Guid.Empty, caseID, service, tracer);
                    return false;
                }
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                return false;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return false;
            }

        }
        public string generateToken(IOrganizationService service, ITracingService tracer)
        {
            try
            {
                string accessToken = null;
                var client = new HttpClient();
                var url = getConfigValue(service, tracer, "GenerateTokenURL");
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                string username = getConfigValue(service, tracer, "GenerateTokenUsername");
                string password = getConfigValue(service, tracer, "GenerateTokenPassword");
                // Combine the username and password, then convert to a Base64 string
                string credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));
                request.Headers.Add("Authorization", $"Basic {credentials}");
                var collection = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials")
            };
                var content = new FormUrlEncodedContent(collection);
                request.Content = content;

                // Send the request synchronously

                var response = client.SendAsync(request).GetAwaiter().GetResult();
                response.EnsureSuccessStatusCode();
                var jsonResponse = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                using (JsonDocument doc = JsonDocument.Parse(jsonResponse))
                {
                    // Access the root element
                    JsonElement root = doc.RootElement;

                    // Get the access_token value
                    if (root.TryGetProperty("access_token", out JsonElement accessTokenElement))
                    {
                        accessToken = accessTokenElement.GetString();
                    }
                }
                return accessToken;
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                //  return null;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return null;
            }
        }
        public string getCustomerNumber(string token, string contract, IOrganizationService service, ITracingService tracer)
        {
            try
            {

                string customerNumber = null;
                var client = new HttpClient();
                var url = getConfigValue(service, tracer, "GetCustomerNumberURL");
                string jsonString = getConfigValue(service, tracer, "GetCustomerNumberRequestParameter");
                CustomerNumberRequestParamter customerNumberRequest = JsonConvert.DeserializeObject<CustomerNumberRequestParamter>(jsonString);
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Authorization", "Bearer " + token);
                var requestHeader = new Dictionary<string, object>
            {
                { "tenantId", customerNumberRequest.TenantId },
                { "userDetail", new Dictionary<string, object>
                    {
                        { "userCode", customerNumberRequest.UserCode },
                        { "branchId", customerNumberRequest.BranchId }
                    }
                }
            };
                var loanRequest = new Dictionary<string, object>
            {
                { "requestHeader", requestHeader },
                { "loanId", "" },
                { "loanAccountNumber", contract },
                { "requestChannel", customerNumberRequest.RequestChannel }
            };
                // Serialize the dictionary to JSON
                var jsonContent = System.Text.Json.JsonSerializer.Serialize(loanRequest);
                // Create StringContent for HTTP request
                var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
                request.Content = content;

                var httpResponse = client.SendAsync(request).GetAwaiter().GetResult();
                // Ensure success status code
                httpResponse.EnsureSuccessStatusCode();
                // Read the response content as a string
                var jsonResponse = httpResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                using (JsonDocument doc = JsonDocument.Parse(jsonResponse))
                {
                    // Navigate to the customer number
                    customerNumber = doc.RootElement
                        .GetProperty("success") // Access the 'success' property
                        .GetProperty("customerDetailMO") // Access the 'customerDetailMO' property
                        .GetProperty("customerNumber") // Access the 'customerNumber' property
                        .GetString(); // Get the value as a string
                }
                return customerNumber;
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);

            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return null;
            }

        }
        public class CustomerNumberRequestParamter
        {
            public string TenantId { get; set; }
            public string UserCode { get; set; }
            public string BranchId { get; set; }
            public string RequestChannel { get; set; }
        }
        public int getRecordID(string token, string customerNumner, string contract, IOrganizationService service, ITracingService tracer)
        {
            try
            {
                int recordId = 0;
                var client = new HttpClient();
                var url = getConfigValue(service, tracer, "GetReocordIDURL");
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Authorization", "Bearer " + token);
                string datePart = DateTime.Now.ToString("dd-MM-yyyy");
                // Generate a random three-digit number
                Random random = new Random();
                int randomNumber = random.Next(1, 1000); // Generates a number between 1 and 999
                                                         // Format the random number to always be three digits (e.g., 001, 045, 123)
                string formattedNumber = randomNumber.ToString("D3");
                // Combine the date and the random number to form the desired string
                string randomRefernceNumber = $"{datePart}_{formattedNumber}";
                string productProcessor = getConfigValue(service, tracer, "GetReocordIDProductProcessor");
                var requestData = new Dictionary<string, object>
            {
                { "associatedLoanAppId", contract },
                { "customerInfoFileNumber", customerNumner },
                { "fetchOnlyDefaultInfoIfNotFoundForAppID", false },
                { "fetchOnlyOnAppID", true },
                { "productProcessor", productProcessor },
                { "requestReferenceNumber", randomRefernceNumber }
            };
                // Serialize the dictionary to a JSON string
                string jsonPayload = JsonConvert.SerializeObject(requestData);
                // Create the StringContent using the serialized JSON string
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                request.Content = content;
                //var httpResponse = client.SendAsync(request).GetAwaiter().GetResult();
                var response = client.SendAsync(request).Result;
                response.EnsureSuccessStatusCode();
                // Ensure success status code
                // Read the response content as a string
                var jsonResponse = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                using (JsonDocument doc = JsonDocument.Parse(jsonResponse))
                {
                    // Navigate to the searchResult array
                    JsonElement searchResultArray = doc.RootElement.GetProperty("searchResult");
                    // Loop through each item in the searchResult array
                    foreach (JsonElement searchResult in searchResultArray.EnumerateArray())
                    {
                        // Navigate to the customerRecord object
                        JsonElement customerRecord = searchResult.GetProperty("customerRecord");
                        // Navigate to the contactInfo array
                        JsonElement contactInfoArray = customerRecord.GetProperty("contactInfo");
                        // Loop through each item in the contactInfo array
                        foreach (JsonElement contactInfo in contactInfoArray.EnumerateArray())
                        {
                            // Navigate to the addressInfo array
                            JsonElement addressInfoArray = contactInfo.GetProperty("addressInfo");
                            // Loop through each item in the addressInfo array
                            foreach (JsonElement addressInfo in addressInfoArray.EnumerateArray())
                            {
                                // Check if the primaryAddress property is true
                                if (addressInfo.GetProperty("primaryAddress").GetBoolean())
                                {
                                    // Retrieve the recordId from addressInfoPojo
                                    recordId = addressInfo.GetProperty("addressInfoPojo").GetProperty("recordId").GetInt32();
                                }
                            }
                        }
                    }
                }
                return recordId;
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                //return 0;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return 0;
            }
        }
        public bool updateAddressDetails(string recordId, string token, string customerNumber, string contract, IOrganizationService service, ITracingService tracer, Guid caseID, Entity postMessageImage)
        {
            try
            {
                string addressType = null;
                if (postMessageImage.Contains("ss_customeraddresstype"))
                {
                    int addressTypeVlaue = ((OptionSetValue)postMessageImage.Attributes["ss_customeraddresstype"]).Value;
                    RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
                    {
                        EntityLogicalName = "incident",  // Replace with your entity name
                        LogicalName = "ss_customeraddresstype",  // Replace with your OptionSet field's logical name
                        RetrieveAsIfPublished = true
                    };
                    // Execute the request
                    RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
                    // Cast the retrieved attribute as a PicklistAttributeMetadata
                    PicklistAttributeMetadata picklistMetadata = (PicklistAttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
                    // Find the matching OptionSet value's label
                    foreach (OptionMetadata optionMetadata in picklistMetadata.OptionSet.Options)
                    {
                        if (optionMetadata.Value == addressTypeVlaue)
                        {
                            string addressTypeLabel = optionMetadata.Label.UserLocalizedLabel.Label;
                            addressType = addressTypeLabel.Replace(" ", "");
                            break;
                        }
                    }
                }
                string customerAccomodationType = null;
                if (postMessageImage.Contains("ss_customeraccomodationtype"))
                {
                    customerAccomodationType = ((EntityReference)postMessageImage.Attributes["ss_customeraccomodationtype"]).Name.ToString();
                }
                string addressLine1 = null;
                if (postMessageImage.Contains("ss_customeraddressline2"))
                {
                    addressLine1 = postMessageImage.Attributes["ss_customeraddressline2"].ToString();
                }
                string addressLine2 = null;
                if (postMessageImage.Contains("ss_customeraddressline3"))
                {
                    addressLine2 = postMessageImage.Attributes["ss_customeraddressline3"].ToString();
                }
                string addressLine3 = null;
                if (postMessageImage.Contains("ss_customeraddressline4"))
                {
                    addressLine3 = postMessageImage.Attributes["ss_customeraddressline4"].ToString();
                }
                string customerArea = null;
                if (postMessageImage.Contains("ss_customerarea"))
                {
                    customerArea = postMessageImage.Attributes["ss_customerarea"].ToString();
                }
                string city = null;
                if (postMessageImage.Contains("ss_customercity"))
                {
                    Guid cityGuid = ((EntityReference)postMessageImage.Attributes["ss_customercity"]).Id;
                    Entity cityEntity = service.Retrieve("new_citymaster", cityGuid, new ColumnSet("new_citycode"));
                    city = cityEntity.Attributes["new_citycode"].ToString();
                }
                string district = null;
                if (postMessageImage.Contains("ss_customerdistrict"))
                {
                    Guid districtGuid = ((EntityReference)postMessageImage.Attributes["ss_customerdistrict"]).Id;
                    Entity districtEntity = service.Retrieve("ccs_districtmaster", districtGuid, new ColumnSet("ccs_district_code"));
                    district = districtEntity.Attributes["ccs_district_code"].ToString();
                }
                string state = null;
                if (postMessageImage.Contains("ss_customerstate"))
                {
                    Guid stateGuid = ((EntityReference)postMessageImage.Attributes["ss_customerstate"]).Id;
                    Entity stateEntity = service.Retrieve("new_statemaster", stateGuid, new ColumnSet("new_statecode"));
                    state = stateEntity.Attributes["new_statecode"].ToString();
                }
                string country = null;
                if (postMessageImage.Contains("ss_customercountry"))
                {
                    Guid countryGuid = ((EntityReference)postMessageImage.Attributes["ss_customercountry"]).Id;
                    Entity countryEntity = service.Retrieve("ss_country", countryGuid, new ColumnSet("ss_code"));
                    country = countryEntity.Attributes["ss_code"].ToString();
                }
                string pinCode = null;
                if (postMessageImage.Contains("ss_customerpincode"))
                {
                    pinCode = postMessageImage.Attributes["ss_customerpincode"].ToString();
                }
                string customerRegion = null;
                if (postMessageImage.Contains("ss_customerregion"))
                {
                    customerRegion = postMessageImage.Attributes["ss_customerregion"].ToString();
                }
                string landMark = null;
                if (postMessageImage.Contains("ss_landmark"))
                {
                    landMark = postMessageImage.Attributes["ss_landmark"].ToString();
                }
                string taluka = null;
                if (postMessageImage.Contains("ss_customertaluka"))
                {
                    Guid talukaGuid = ((EntityReference)postMessageImage.Attributes["ss_customertaluka"]).Id;
                    Entity talukaEntity = service.Retrieve("ccs_talukamaster", talukaGuid, new ColumnSet("ccs_taluka_code"));
                    taluka = talukaEntity.Attributes["ccs_taluka_code"].ToString();
                }
                string customerResidenceType = null;
                if (postMessageImage.Contains("ss_customerresidencetype"))
                {
                    customerResidenceType = postMessageImage.Attributes["ss_customerresidencetype"].ToString();
                }
                string customerResidenceStatus = null;
                if (postMessageImage.Contains("ss_customerresidencestatus"))
                {
                    customerResidenceStatus = postMessageImage.Attributes["ss_customerresidencestatus"].ToString();
                }
                string flatPlotNumber = null;
                if (postMessageImage.Contains("ss_customerflatplotnumber"))
                {
                    flatPlotNumber = postMessageImage.Attributes["ss_customerflatplotnumber"].ToString();
                }
                string jsonString = getConfigValue(service, tracer, "AddressUpdateRequestParameter");
                CustomerNumberRequestParamter updateAddressRequest = JsonConvert.DeserializeObject<CustomerNumberRequestParamter>(jsonString);
                var client = new HttpClient();
                var url = getConfigValue(service, tracer, "AddressUpdateURL");
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Authorization", "Bearer " + token);
                var requestData = new Dictionary<string, object>
            {
                {
                    "requestHeader", new Dictionary<string, object>
                    {
                        { "tenantId", updateAddressRequest.TenantId },
                        {
                            "userDetail", new Dictionary<string, object>
                            {
                                { "userCode", updateAddressRequest.UserCode },
                                { "branchId", updateAddressRequest.BranchId }
                            }
                        }
                    }
                },
                { "requestChannel", updateAddressRequest.RequestChannel },
                { "loanAccountNumber", contract },
                { "associatedLoanAppId", contract },
                { "customerNumber", customerNumber },
                { "recordId", recordId },
                {
                    "addressInfoPdePOJO", new Dictionary<string, object>
                    {
                        { "preferredMailingAddress", true },
                        { "addressType", addressType },
                        { "accomodationType", customerAccomodationType },
                        { "addressLine1", addressLine1},
                        { "addressLine2", addressLine2},
                        { "addressLine3", addressLine3 },
                        { "area", customerArea},
                        { "village","" },
                        { "city", city},
                        { "district", district },
                        { "state", state },
                        { "country", country },
                        { "zipcode", pinCode },
                        { "region", customerRegion },
                        { "landMark", landMark},
                        { "taluka", taluka},
                        { "residenceType", customerResidenceType },
                        { "additionalAddressPurpose", "" },
                        { "additionalField1", flatPlotNumber},
                        { "additionalField2", customerResidenceStatus },
                        { "additionalField3", "" },
                        { "additionalField4", "" },
                        { "additionalField5", "" },
                        { "addressGeneric", "YES" },
                        { "generateCommunication", false },
                        { "copytoCommunication", false },
                        { "phoneNumbers", new List<object>() }, // Assuming this is an empty array
                        { "attachmentDetails", new Dictionary<string, object>() } // Assuming this is an empty object
                    }
                },
                { "autoAuthorizeFlag", "Y" }
            };
                string jsonPayload = JsonConvert.SerializeObject(requestData);
                // Create the StringContent using the serialized JSON string
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                request.Content = content;
                try
                {
                    var response = client.SendAsync(request).Result;
                    response.EnsureSuccessStatusCode();
                    // Ensure success status code
                    // Read the response content as a string
                    var jsonResponse = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    using (JsonDocument document = JsonDocument.Parse(jsonResponse))
                    {
                        if (document.RootElement.TryGetProperty("responseCode", out JsonElement responseCodeElement))
                        {
                            string responseCode = responseCodeElement.GetString();
                            if (responseCode == "success")
                            {
                                Guid ID = createAuditLog("Update Address Details", jsonPayload, jsonResponse, true, 1, Guid.Empty, caseID, service, tracer);

                            }
                            else
                            {
                                Guid ID = createAuditLog("Update Address Details", jsonPayload.ToString(), jsonResponse, false, 1, Guid.Empty, caseID, service, tracer);
                                return false;
                            }
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Guid ID = createAuditLog("Update Address AutoFin Details", jsonPayload.ToString(), ex.Message, false, 1, Guid.Empty, caseID, service, tracer);
                    return false;
                }
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                return false;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return false;
            }
        }
        public Guid createAuditLog(string webmethodName, string JSONFormat, string Response, bool isSuccess,
           int direction, Guid AuditLogId, Guid CaseID, IOrganizationService service, ITracingService tracer)
        {
            try
            {
                tracer.Trace("(Case Assignment Update Plugin) CreateAuditLog " + webmethodName);
                Entity auditLog = new Entity("ccs_webservice_audit_log");
                auditLog.Attributes["ccs_direction"] = new OptionSetValue(direction);
                auditLog.Attributes["ccs_is_success"] = isSuccess;
                if (CaseID != Guid.Empty)
                    auditLog.Attributes["ccs_case"] = new EntityReference("incident", CaseID);
                auditLog.Attributes["ccs_enquirywebservice"] = JSONFormat;
                auditLog.Attributes["ccs_webresponse"] = Response;
                // auditLog.Attributes["ccs_system"] = new EntityReference("ccs_system_webservice_configuration", systemName);
                auditLog.Attributes["ccs_name"] = webmethodName;
                auditLog.Attributes["ccs_entrydatetime"] = DateTime.Now;
                if (AuditLogId == Guid.Empty)
                    AuditLogId = service.Create(auditLog);
                else
                {
                    auditLog.Id = AuditLogId;
                    service.Update(auditLog);
                }
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return Guid.Empty;
            }
            return AuditLogId;
        }
        public void closeCase(Guid id, IOrganizationService service)
        {
            try
            {
                Entity incidentResolution = new Entity("incidentresolution");
                incidentResolution["subject"] = "As per the request raised by the customer , we have reviewed and closed the request for loan closure.";
                incidentResolution["incidentid"] = new EntityReference("incident", id);
                Entity Case = new Entity("incident");
                Case.Id = id;
                Case.Attributes["ccs_cancelcasecomments"] = "As per the request raised by the customer , we have reviewed and closed the request for loan closure.";
                Case.Attributes["ccs_reasonsforsuchresolutions"] = "As per the request raised by the customer , we have reviewed and closed the request for loan closure.";
                Case.Attributes["ccs_pointwasresponseforthecomplainraisedandif"] = "As per the request raised by the customer , we have reviewed and closed the request for loan closure.";
                Case.Attributes["ccs_outcome"] = "As per the request raised by the customer , we have reviewed and closed the request for loan closure.";
                service.Update(Case);

                // Close the incident with the resolution.
                CloseIncidentRequest closeIncidentRequest = new CloseIncidentRequest()
                {
                    IncidentResolution = incidentResolution,
                    Status = new OptionSetValue(5)
                };
                service.Execute(closeIncidentRequest);
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                //tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
            }
            catch (Exception ex)
            {
                // tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                // return Guid.Empty;
            }
        }
        public string getConfigValue(IOrganizationService service, ITracingService tracer, string key, string subkey = "", bool throwExceptionIfNotFound = true)
        {
            try
            {
                tracer.Trace("GetConfigValue start");
                if (!string.IsNullOrEmpty(key))
                {
                    QueryByAttribute query = new QueryByAttribute("ss_configuration");
                    query.ColumnSet = new ColumnSet("ss_value");
                    query.Attributes.Add("ss_key");
                    query.Values.Add(key);

                    if (!string.IsNullOrEmpty(subkey))
                    {
                        query.Attributes.Add("ss_subkey");
                        query.Values.Add(subkey);
                    }

                    EntityCollection config = service.RetrieveMultiple(query);

                    if (config.Entities.Count > 0)
                        return config.Entities[0]["ss_value"].ToString();
                    else
                        return string.Empty;

                }
                else
                    return string.Empty;
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                return null;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return null;
            }
        }
        public class FinPersonalDetailsRequestParameter
        {
            public string ProductProcessor { get; set; }
            public string RequestReferenceNumber { get; set; }
        }
        public bool updatePersonalDetails(string token, string customerNumber, string contract, IOrganizationService service, ITracingService tracer, Guid caseID, Entity postMessageImage, int personalDetails)
        {
            try
            {
                string methodName = null;
                string jsonString = getConfigValue(service, tracer, "UpdatePersonalDetailsRequestParameter");
                FinPersonalDetailsRequestParameter finPersonalDetailsRequest = JsonConvert.DeserializeObject<FinPersonalDetailsRequestParameter>(jsonString);
                var requestData = new Dictionary<string, object>();
                if (personalDetails == 1 && postMessageImage.Contains("ss_newdateofbirth"))
                {
                    methodName = "DOB";
                    DateTime updatedDOBDateTeime = ((DateTime)postMessageImage.Attributes["ss_newdateofbirth"]);
                    string updateDOB = updatedDOBDateTeime.ToString("yyyy-MM-dd");
                    requestData = new Dictionary<string, object>
                        {
                            { "productProcessor", finPersonalDetailsRequest.ProductProcessor },
                            { "requestReferenceNumber", finPersonalDetailsRequest.RequestReferenceNumber },
                            { "updateGlobalCustomer", new Dictionary<string, object>
                                {
                                    { "associatedLoanAppId", contract },
                                    { "customerInfoFileNumber", customerNumber },
                                    { "personInfo", new Dictionary<string, object>
                                        {
                                            { "dateOfBirth", updateDOB }
                                        }
                                    }
                                }
                            }
                        };

                }
                else if (personalDetails == 2 && postMessageImage.Contains("ss_newgender"))
                {
                    methodName = "Gender";
                    string gender = null;
                    var updatedDOBDateTeime = ((OptionSetValue)postMessageImage.Attributes["ss_newgender"]).Value;
                    if (updatedDOBDateTeime.Equals(0))
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "Female";
                    }
                    requestData = new Dictionary<string, object>
                        {
                            { "productProcessor", finPersonalDetailsRequest.ProductProcessor },
                            { "requestReferenceNumber", finPersonalDetailsRequest.RequestReferenceNumber },
                            { "updateGlobalCustomer", new Dictionary<string, object>
                                {
                                    { "associatedLoanAppId", contract },
                                    { "customerInfoFileNumber", customerNumber },
                                    { "personInfo", new Dictionary<string, object>
                                        {
                                            { "gender", gender }
                                        }
                                    }
                                }
                            }
                         };


                }
                else if (personalDetails == 3 && (postMessageImage.Contains("ss_firstname") || postMessageImage.Contains("ss_secondname") || postMessageImage.Contains("ss_surname")))
                {
                    methodName = "Name";
                    string firstName = null;
                    string middleName = null;
                    string lastName = null;
                    if (postMessageImage.Contains("ss_firstname"))
                    {
                        firstName = postMessageImage.Attributes["ss_firstname"].ToString();
                    }
                    if (postMessageImage.Contains("ss_secondname"))
                    {
                        middleName = postMessageImage.Attributes["ss_secondname"].ToString();
                    }
                    if (postMessageImage.Contains("ss_surname"))
                    {
                        lastName = postMessageImage.Attributes["ss_surname"].ToString();
                    }
                    requestData = new Dictionary<string, object>
                        {
                            { "productProcessor", finPersonalDetailsRequest.ProductProcessor },
                            { "requestReferenceNumber", finPersonalDetailsRequest.RequestReferenceNumber },
                            { "updateGlobalCustomer", new Dictionary<string, object>
                                {
                                    { "associatedLoanAppId", contract },
                                    { "customerInfoFileNumber", customerNumber },
                                    { "personInfo", new Dictionary<string, object>
                                        {
                                            { "firstName", firstName },
                                            { "middleName", middleName },
                                            { "lastName", lastName }
                                        }
                                    }
                                }
                            }
                        };

                }

                var client = new HttpClient();
                var url = getConfigValue(service, tracer, "UpdatePersonalDetailsURL");
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Authorization", "Bearer " + token);
                // Serialize the dictionary to a JSON string
                string jsonPayload = JsonConvert.SerializeObject(requestData);
                // Create the StringContent using the serialized JSON string
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                request.Content = content;
                try
                {
                    var response = client.SendAsync(request).Result;
                    response.EnsureSuccessStatusCode();
                    // Ensure success status code
                    // Read the response content as a string
                    var jsonResponse = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    using (JsonDocument document = JsonDocument.Parse(jsonResponse))
                    {
                        if (document.RootElement.TryGetProperty("status", out JsonElement responseCodeElement))
                        {
                            string responseCode = responseCodeElement.GetString();
                            if (responseCode.ToLower() == "success")
                            {
                                Guid ID = createAuditLog("Update Personal Details " + methodName, jsonPayload, jsonResponse, true, 1, Guid.Empty, caseID, service, tracer);
                                // closeCase(caseID, service);
                            }
                            else
                            {
                                Guid ID = createAuditLog("Update Personal Details " + methodName, jsonPayload, jsonResponse, false, 1, Guid.Empty, caseID, service, tracer);
                                return false;
                            }
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Guid ID = createAuditLog("Update Personal Details " + methodName, jsonPayload, ex.Message, false, 1, Guid.Empty, caseID, service, tracer);
                    return false;
                }

            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                return false;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return false;
            }


        }
        public class AutoFinPersonalDetailsRequestParameter
        {
            public string UserId { get; set; }
            public string Source { get; set; }
        }
        public bool updateAutoFinPersonalDetails(double clusterID, IOrganizationService service, ITracingService tracer, Guid caseID, Entity postMessageImage, int personalDetails)
        {
            try
            {
                string methodName = "";
                string updateDOB = "";
                string gender = "";
                string firstName = "";
                string middleName = "";
                string lastName = "";
                string panNumber = "";
                string titleName = "";
                string jsonStringAutoFIN = getConfigValue(service, tracer, "RequestParameterforPersonalDetailsUpdate");
                AutoFinPersonalDetailsRequestParameter autoFinPersonalDetailsRequestParameter = JsonConvert.DeserializeObject<AutoFinPersonalDetailsRequestParameter>(jsonStringAutoFIN);
                if (personalDetails == 1 && postMessageImage.Contains("ss_newdateofbirth"))
                {
                    methodName = "DOB";
                    DateTime updatedDOBDateTeime = ((DateTime)postMessageImage.Attributes["ss_newdateofbirth"]);
                    updateDOB = updatedDOBDateTeime.ToString("yyyy-MM-dd");
                }
                else if (personalDetails == 2 && postMessageImage.Contains("ss_newgender"))
                {
                    methodName = "GENDER";
                    var updatedDOBDateTime = ((OptionSetValue)postMessageImage.Attributes["ss_newgender"]).Value;
                    if (updatedDOBDateTime.Equals(0))
                    {
                        gender = "Male";
                    }
                    else
                    {
                        gender = "Female";
                    }
                }
                else if (personalDetails == 3 && (postMessageImage.Contains("ss_firstname") || postMessageImage.Contains("ss_secondname") || postMessageImage.Contains("ss_surname")))
                {
                    methodName = "NAME";
                    if (postMessageImage.Contains("ss_customertitle"))
                    {
                        var title = ((OptionSetValue)postMessageImage.Attributes["ss_customertitle"]).Value;
                        if (title.Equals(0))
                        {
                            titleName = "MR.";
                        }
                        else
                        {
                            titleName = "MRS.";
                        }
                    }
                    if (postMessageImage.Contains("ss_firstname"))
                    {
                        firstName = postMessageImage.Attributes["ss_firstname"].ToString();
                    }
                    if (postMessageImage.Contains("ss_secondname"))
                    {
                        middleName = postMessageImage.Attributes["ss_secondname"].ToString();
                    }
                    if (postMessageImage.Contains("ss_surname"))
                    {
                        lastName = postMessageImage.Attributes["ss_surname"].ToString();
                    }
                }
                else if (personalDetails == 4 && postMessageImage.Contains("ss_newpannumber"))
                {
                    methodName = "PAN";
                    panNumber = postMessageImage.Attributes["ss_newpannumber"].ToString();
                }
                var url = getConfigValue(service, tracer, "UpdateAutoFinPersonalDetailsURL");
                //Entity accountEntity = service.Retrieve("account", customerID, new ColumnSet("ccs_clustercontactidid", "accountid"));
                //string clusterNumber = null;
                //if (accountEntity.Attributes.Contains("ccs_clustercontactidid"))
                //{
                //    clusterNumber = ((EntityReference)accountEntity.Attributes["ccs_clustercontactidid"]).Name;
                //}
                var apiKey = getConfigValue(service, tracer, "APIKEYforPersonalDetailsUpdate");
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("apikey", apiKey);
                var data = new Dictionary<string, string>
                {
                    { "clusterNumber", clusterID.ToString() },
                    { "title", titleName },
                    { "firstName", firstName },
                    { "secondName", middleName },
                    { "surname", lastName },
                    { "dateOfBirth", updateDOB },
                    { "panNumber", panNumber },
                    { "gender", gender },
                    { "constitution", "" },
                    { "userId", autoFinPersonalDetailsRequestParameter.UserId },
                    { "source", autoFinPersonalDetailsRequestParameter.Source },
                    { "flag", methodName },
                    { "process", "" }
                };
                var jsonString = JsonConvert.SerializeObject(data);
                var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                request.Content = content;
                try
                {
                    var response = client.SendAsync(request).Result;
                    response.EnsureSuccessStatusCode();
                    // Ensure success status code
                    // Read the response content as a string
                    var jsonResponse = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    using (JsonDocument document = JsonDocument.Parse(jsonResponse))
                    {
                        if (document.RootElement.TryGetProperty("status", out JsonElement responseCodeElement))
                        {
                            string responseCode = responseCodeElement.GetString();
                            if (responseCode.ToLower() == "success")
                            {
                                Guid ID = createAuditLog("Update AutoFin Personal Details " + methodName, jsonString, jsonResponse, true, 1, Guid.Empty, caseID, service, tracer);
                                // closeCase(caseID, service);
                            }
                            else
                            {
                                Guid ID = createAuditLog("Update AutoFin Personal " + methodName, jsonString, jsonResponse, false, 1, Guid.Empty, caseID, service, tracer);
                                return false;

                            }
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Guid ID = createAuditLog("Update AutoFin Personal " + methodName, jsonString, ex.Message, false, 1, Guid.Empty, caseID, service, tracer);
                    return false;
                }
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog FaultException: " + ex.Message);
                // throw new Exception("plugin Error in Create Audit Log: " + ex.Detail.TraceText);
                return false;
            }
            catch (Exception ex)
            {
                tracer.Trace("(Address Update Plugin) CreateAuditLog Exception: " + ex.Message);
                return false;
            }

        }

        public Contract GetContractDetails(IOrganizationService service, ITracingService tracer, Guid contractID, Guid caseID)//, Entity entity)
        {

            tracer.Trace("GetClusterID Started");
            string ClusterId = "";
            Entity CaseIncident = new Entity("incident");
            //var ContractID = ((EntityReference)entity.Attributes["ccs_contract"]).Id;
            //tracer.Trace("Contract ID:" + ContractID);
            var ContractMaster = service.Retrieve("ccs_contractmaster", contractID, new ColumnSet("ccs_contractnumber"));
            //var ContractNumber = ((EntityReference)entity.Attributes["ccs_contract"]).Name.ToString();
            var ContractNumber = string.Empty;
            if (ContractMaster.Attributes.Contains("ccs_contractnumber"))
            {
                ContractNumber = ContractMaster.Attributes["ccs_contractnumber"].ToString();
            }
            tracer.Trace("ContractNumber:" + ContractNumber);
            Guid Webserviceid;
            string Webserviceurl = string.Empty;
            string jsondata = string.Empty, responsetext = string.Empty, errormessage = string.Empty;
            bool responsestatus = false;
            Contract contract = new Contract();
            EntityCollection TokenResult = GetSystemConnectionConfig("GetClusterID", service);
            if (TokenResult.Entities.Count > 0 && !string.IsNullOrEmpty(ContractNumber))
            {
                if (TokenResult.Entities[0].Attributes.Contains("ccs_system_webservice_configurationid"))
                {
                    Webserviceid = Guid.Parse(TokenResult.Entities[0].Attributes["ccs_system_webservice_configurationid"].ToString());
                    if (TokenResult.Entities[0].Attributes.Contains("ccs_ws_url"))
                    {
                        Webserviceurl = TokenResult.Entities[0].Attributes["ccs_ws_url"].ToString();
                    }

                    #region GetClusterID Process start
                    string jsonResponse = string.Empty;
                    try
                    {
                        GetClusterIDRequest req = new GetClusterIDRequest()
                        {
                            ContractNo = ContractNumber
                        };
                        //jsondata = Serialize(req);
                        HttpWebRequest myHttpWebRequest = null;
                        HttpWebResponse myHttpWebResponse = null;
                        DataContractJsonSerializer serializerToUplaod = new DataContractJsonSerializer(typeof(GetClusterIDRequest));
                        MemoryStream ms = new MemoryStream();
                        serializerToUplaod.WriteObject(ms, req);
                        jsondata = Encoding.UTF8.GetString(ms.ToArray());
                        byte[] postBytes = Encoding.UTF8.GetBytes(jsondata);
                        System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)(768 | 3072);
                        myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create(Webserviceurl);
                        myHttpWebRequest.Method = "POST";
                        myHttpWebRequest.ContentType = "application/json";
                        myHttpWebRequest.ContentLength = postBytes.Length;
                        Stream requestStream = myHttpWebRequest.GetRequestStream();
                        requestStream.Write(postBytes, 0, postBytes.Length);
                        requestStream.Close();
                        myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                        StreamReader sr = new StreamReader(myHttpWebResponse.GetResponseStream());
                        jsonResponse = sr.ReadToEnd();
                        tracer.Trace("jsonResponse" + jsonResponse);
                        contract = JsonConvert.DeserializeObject<Contract>(jsonResponse);

                        if (contract.ContractDetails.Count > 0)
                        {
                            ClusterId = (Convert.ToInt64(contract.ContractDetails[0].CLUSTER_ID)).ToString();
                            CaseIncident.Id = caseID;
                            CaseIncident["ss_clusteridforcontract"] = ClusterId.ToString();
                            CaseIncident["ss_getclusteridresponse"] = jsonResponse;
                            service.Update(CaseIncident);
                            responsestatus = true;
                            tracer.Trace("ClusterId" + ClusterId);
                        }

                    }
                    catch (Exception ex)
                    {
                        responsestatus = false; // Exception
                        jsonResponse = ex.Message;
                    }
                    tracer.Trace("responsestatus" + responsestatus);

                    createAuditLog("Get Cluster ID", jsondata, jsonResponse, responsestatus, 0, Guid.Empty, caseID, service, tracer);
                }
                #endregion
            }
            tracer.Trace("ClusterId" + ClusterId);
            return contract;
        }
        public class Contract
        {
            public List<ContractDetail> ContractDetails { get; set; }
        }
        public class ContractDetail
        {
            public string REFERENCE_NUMBER { get; set; }
            public string ENTITY_CODE { get; set; }
            public double CLUSTER_ID { get; set; }
            public string SOURCE { get; set; }

        }
        public class GetClusterIDRequest
        {
            public string ContractNo { get; set; }
        }
        public EntityCollection GetSystemConnectionConfig(string systemName, IOrganizationService service)
        {
            Guid webServiceConfigId = Guid.Empty;
            StringBuilder fetchXML = new StringBuilder();

            try
            {
                fetchXML.Append("<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' no-lock='true'>");
                fetchXML.Append("<entity name='ccs_system_webservice_configuration'>");
                fetchXML.Append("<all-attributes/>");
                fetchXML.Append("<filter type='and'>");
                fetchXML.Append("<condition attribute='ccs_name' operator='eq' value = '" + systemName + "'/>");
                fetchXML.Append("</filter>");
                fetchXML.Append("</entity></fetch>");

                EntityCollection systemDetails = service.RetrieveMultiple(new FetchExpression(fetchXML.ToString()));
                return systemDetails;
            }
            catch (Exception ex)
            {
                //Logger.Write(ex.Message + ex.StackTrace);
                throw new Exception("Error in GetSystemConnectionConfig:" + ex.Message);
            }
        }
    }
}
