﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProjectQuiz
{
    public partial class InstructionPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonTC_Click(object sender, EventArgs e)
        {

        }

        protected void ButtonTC_Click1(object sender, EventArgs e)
        {
            if (CheckBoxTC.Checked)
            {
                Response.Redirect("Quiz.html");
            }
            else
            {
                LabelWrongTC.Text = "Please click on the Checkbox";
            }
        }
    }
}