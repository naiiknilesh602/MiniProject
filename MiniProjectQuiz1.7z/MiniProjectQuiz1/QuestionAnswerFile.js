﻿var myQuestions = [
    {
        "question": "What is 10/2?",
        
            "a": "3",
            "b": "5",
            "c": "115",
        
        "correctAnswer": "b"
    },
    {
        "question": "What is 30/3?",
            "a": "3",
            "b": "5",
            "c": "10",
        "correctAnswer": "c"
    }
];
var i = 0;
var CorrectCount = 0;

function generate(index) {
   
        document.getElementById("question").innerHTML = myQuestions[index].question;
    document.getElementById("Optt1").innerHTML = myQuestions[index].a;
    document.getElementById("Optt2").innerHTML = myQuestions[index].b;
    document.getElementById("Optt3").innerHTML = myQuestions[index].c;
}
function CheckAns() {
    for (i = 0; i < myQuestions.length; i++) {
        generate(i);
        if (document.getElementById("Opt1").checked && myQuestions[i].a == myQuestions[i].correctAnswer) {
            CorrectCount++;
        }
        if (document.getElementById("Opt2").checked && myQuestions[i].b == myQuestions[i].correctAnswer) {
            CorrectCount++;
        }
        if (document.getElementById("Opt3").checked && myQuestions[i].c == myQuestions[i].correctAnswer) {
            CorrectCount++;
        }
    }

    if (myQuestions.length - 1 < i) {
        document.write("Your Score is : " + CorrectCount);
    }

}
