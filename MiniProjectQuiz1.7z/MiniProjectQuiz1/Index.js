﻿var i = 0;
var CorrectCount = 0;

function generate(index) {
    var myQuestions = [
    document.getElementById("question").innerHTML = myQuestions[index].;
    document.getElementById("Optt1").innerHTML = myQuestions[index].a;
    document.getElementById("Optt2").innerHTML = myQuestions[index].b;
    document.getElementById("Optt3").innerHTML = myQuestions[index].c;
}
function CheckAns() {
    for (i = 0; i < myQuestions.length; i++) {
        generate(i);
        if (document.getElementById("Opt1").checked && myQuestions[i].a == myQuestions[i].correctAnswer) {
            CorrectCount++;
        }
        if (document.getElementById("Opt2").checked && myQuestions[i].b == myQuestions[i].correctAnswer) {
            CorrectCount++;
        }
        if (document.getElementById("Opt3").checked && myQuestions[i].c == myQuestions[i].correctAnswer) {
            CorrectCount++;
        }
    }

    if (myQuestions.length - 1 < i) {
        document.write("Your Score is : " + CorrectCount);
    }
       
    }
    
    
    

   