﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiniProjectQuiz
{
    public partial class LogInPage : System.Web.UI.Page
    {
        protected void ButtonlogIn_Click(object sender, EventArgs e)
        {
        }

        protected void TextBoxUserName_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}